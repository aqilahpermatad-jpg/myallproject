# Dashboard Data Fiskal

Dashboard interaktif berbasis Streamlit untuk dataset CSV di repository GitHub.

## Cara menjalankan di komputer

1. Pastikan Python sudah terpasang.
2. Buka terminal/Command Prompt di folder ini.
3. Install dependensi:

   ```bash
   pip install -r requirements.txt
   ```

4. Jalankan dashboard:

   ```bash
   streamlit run app.py
   ```

5. Dashboard akan terbuka di browser. Pastikan komputer terhubung ke internet karena CSV dibaca langsung dari GitHub.

## Fitur
- Filter daerah dan rentang tahun
- Ringkasan jumlah observasi dan variabel
- Grafik tren tahunan
- Scatter plot dan korelasi Pearson
- Tabel data dan unduh CSV hasil filter

Catatan: nilai yang ditampilkan mengikuti isi dataset sumber. Periksa definisi variabel dan satuannya sebelum digunakan dalam laporan.
