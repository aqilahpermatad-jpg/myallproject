import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(
    page_title="Dashboard Data Fiskal",
    page_icon="📊",
    layout="wide"
)

DATA_URL = "https://raw.githubusercontent.com/aqilahpermatad-jpg/myallproject/main/dataset_fiskal_97_hipoFull%20(3).csv"

st.markdown("""
<style>
    .block-container {padding-top: 1.5rem; padding-bottom: 2rem;}
    [data-testid="stMetric"] {
        background: #ffffff;
        border: 1px solid #e8edf3;
        padding: 16px 18px;
        border-radius: 14px;
        box-shadow: 0 3px 12px rgba(25, 45, 80, 0.04);
    }
    h1, h2, h3 { letter-spacing: -0.4px; }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_data():
    data = pd.read_csv(DATA_URL)
    data.columns = data.columns.str.strip()
    if "Tahun" in data.columns:
        data["Tahun"] = pd.to_numeric(data["Tahun"], errors="coerce").astype("Int64")
    return data

st.sidebar.title("📊 Menu Dashboard")
st.sidebar.caption("Analisis data fiskal dan indikator sosial")
page = st.sidebar.radio(
    "Navigasi",
    ["Ringkasan", "Tren Tahunan", "Hubungan Variabel", "Data Mentah"]
)

try:
    df = load_data()
except Exception as e:
    st.error("Dataset gagal dimuat dari GitHub. Periksa koneksi internet atau URL dataset.")
    st.code(str(e))
    st.stop()

st.title("Dashboard Data Fiskal Daerah")
st.write("Ringkasan, tren, dan eksplorasi indikator fiskal serta sosial berdasarkan dataset GitHub.")

# Filters
filtered = df.copy()
st.sidebar.subheader("Filter Data")

if "Kota" in df.columns:
    cities = sorted(df["Kota"].dropna().astype(str).unique().tolist())
    selected_cities = st.sidebar.multiselect("Pilih daerah", cities, default=cities)
    if selected_cities:
        filtered = filtered[filtered["Kota"].astype(str).isin(selected_cities)]
    else:
        filtered = filtered.iloc[0:0]

if "Tahun" in df.columns and df["Tahun"].notna().any():
    years = sorted(df["Tahun"].dropna().astype(int).unique().tolist())
    if years:
        selected_years = st.sidebar.slider(
            "Rentang tahun",
            min_value=min(years),
            max_value=max(years),
            value=(min(years), max(years))
        )
        filtered = filtered[
            filtered["Tahun"].between(selected_years[0], selected_years[1])
        ]

numeric_cols = filtered.select_dtypes(include="number").columns.tolist()
if "Tahun" in numeric_cols:
    numeric_cols.remove("Tahun")

if filtered.empty:
    st.warning("Tidak ada data untuk kombinasi filter tersebut. Silakan ubah filter.")
    st.stop()

if page == "Ringkasan":
    st.subheader("Ringkasan Data")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Jumlah observasi", f"{len(filtered):,}")
    c2.metric("Jumlah daerah", f"{filtered['Kota'].nunique():,}" if "Kota" in filtered.columns else "—")
    c3.metric("Rentang tahun", f"{int(filtered['Tahun'].min())}–{int(filtered['Tahun'].max())}" if "Tahun" in filtered.columns and filtered["Tahun"].notna().any() else "—")
    c4.metric("Variabel numerik", f"{len(numeric_cols):,}")

    st.divider()
    left, right = st.columns([1.25, 1])
    with left:
        st.subheader("Tren indikator")
        if numeric_cols:
            default_y = "KEMISKINAN" if "KEMISKINAN" in numeric_cols else numeric_cols[0]
            y_var = st.selectbox("Pilih indikator", numeric_cols, index=numeric_cols.index(default_y))
            if "Tahun" in filtered.columns:
                trend = filtered.groupby("Tahun", as_index=False)[y_var].mean()
                fig = px.line(trend, x="Tahun", y=y_var, markers=True,
                              title=f"Rata-rata {y_var} per Tahun")
                fig.update_layout(margin=dict(l=10, r=10, t=55, b=10))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Kolom Tahun tidak ditemukan pada dataset.")
    with right:
        st.subheader("Statistik indikator")
        if numeric_cols:
            stat_var = st.selectbox("Variabel statistik", numeric_cols, key="stat_var")
            stats = filtered[stat_var].describe().rename({
                "count": "Jumlah data", "mean": "Rata-rata", "std": "Simpangan baku",
                "min": "Minimum", "25%": "Kuartil 1", "50%": "Median",
                "75%": "Kuartil 3", "max": "Maksimum"
            })
            st.dataframe(stats.to_frame("Nilai").round(3), use_container_width=True)

    st.subheader("Pratinjau data")
    st.dataframe(filtered.head(10), use_container_width=True, hide_index=True)

elif page == "Tren Tahunan":
    st.subheader("Tren Tahunan")
    if not numeric_cols or "Tahun" not in filtered.columns:
        st.warning("Kolom numerik atau Tahun tidak tersedia.")
    else:
        chosen = st.multiselect(
            "Pilih indikator yang ingin dibandingkan",
            numeric_cols,
            default=[c for c in ["DBH_PAJAK", "PAD", "KEMISKINAN"] if c in numeric_cols][:3]
        )
        if chosen:
            trend = filtered.groupby("Tahun", as_index=False)[chosen].mean()
            long = trend.melt(id_vars="Tahun", var_name="Indikator", value_name="Nilai")
            fig = px.line(long, x="Tahun", y="Nilai", color="Indikator", markers=True)
            fig.update_layout(legend_title_text="Indikator", margin=dict(l=10, r=10, t=25, b=10))
            st.plotly_chart(fig, use_container_width=True)
            st.caption("Grafik menampilkan rata-rata per tahun dari daerah yang dipilih.")
        else:
            st.info("Pilih setidaknya satu indikator.")

elif page == "Hubungan Variabel":
    st.subheader("Eksplorasi Hubungan Variabel")
    if len(numeric_cols) < 2:
        st.warning("Diperlukan minimal dua variabel numerik.")
    else:
        default_x = "DBH_PAJAK" if "DBH_PAJAK" in numeric_cols else numeric_cols[0]
        default_y = "KEMISKINAN" if "KEMISKINAN" in numeric_cols else numeric_cols[1]
        a, b = st.columns(2)
        with a:
            x_var = st.selectbox("Variabel X", numeric_cols, index=numeric_cols.index(default_x))
        with b:
            y_var = st.selectbox("Variabel Y", numeric_cols, index=numeric_cols.index(default_y))
        color_var = "Tahun" if "Tahun" in filtered.columns else None
        fig = px.scatter(
            filtered, x=x_var, y=y_var,
            color=color_var,
            hover_name="Kota" if "Kota" in filtered.columns else None,
            trendline="ols"
        )
        st.plotly_chart(fig, use_container_width=True)
        corr = filtered[[x_var, y_var]].corr().iloc[0, 1]
        st.metric("Korelasi Pearson", f"{corr:.3f}" if pd.notna(corr) else "Tidak tersedia")
        st.caption("Korelasi menunjukkan hubungan linear, bukan bukti sebab-akibat.")

else:
    st.subheader("Data Mentah")
    st.write(f"Menampilkan **{len(filtered):,}** baris sesuai filter.")
    search = st.text_input("Cari kata pada data (misalnya nama daerah)")
    display_df = filtered
    if search.strip():
        mask = display_df.astype(str).apply(
            lambda col: col.str.contains(search.strip(), case=False, na=False)
        ).any(axis=1)
        display_df = display_df[mask]
    st.dataframe(display_df, use_container_width=True, hide_index=True)
    csv = display_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Unduh data hasil filter (CSV)",
        data=csv,
        file_name="data_fiskal_filtered.csv",
        mime="text/csv"
    )

st.sidebar.divider()
st.sidebar.caption("Sumber data: repository GitHub myallproject.")
st.caption("Catatan: periksa definisi, satuan, dan kualitas data sebelum menarik kesimpulan penelitian.")
